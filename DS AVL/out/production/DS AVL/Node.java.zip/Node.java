import java.util.Scanner;

public class Node {

//--------------------------------------------------------LinkedList

    private Node root;
    private Node left = null;
    private Node right = null;
    private double value;
    private double height;


    public Node() {
    }

    private Node(double value1) {

        value = value1;
        height = 1;
        root = null;
    }

//--------------------------------------------------------DefaultEntry

    public void add(double value) {

        System.out.println("added");
        root = addfunction(root, value);
    }

    public void find(double value) {

        boolean t = Search(root, value);
        if (t == true) {
            System.out.println(value);
        }
        if (t == false) {
            System.out.println("not found");
        }
    }

    public void remove(double value) {

        doremove(root, value);

    }
    
//--------------------------------------------------------Main

    public static void main(String[] args) {
        Node node = new Node();
        Scanner scanner1 = new Scanner(System.in);
        String g = scanner1.nextLine();
        int g1 = Integer.parseInt(g);

        for (int i = 0; i < g1; i++) {
            String a = scanner1.nextLine();
            String[] b = a.split(" ");
            if (b[0].equals("add")) {
                node.add(Double.parseDouble(b[1]));
            }
            if (b[0].equals("find")) {
                node.find(Double.parseDouble(b[1]));
            }
            if (b[0].equals("remove")) {
                node.remove(Double.valueOf(b[1]));
            }
        }
        scanner1.close();

    }
//-------------------------------------------------------PrivateFunctions

    private double GetNodeHeight(Node node) {

        double thisheight;

        if (node == null) {

            thisheight = 0;
        } else {

            thisheight = node.height;
        }
        return thisheight;
    }

    private Node inorderSmaller(Node node) {

        Node currnode = node.right;
        if (currnode == null)
            return null;

        while (currnode.left != null) {
            currnode = currnode.left;
        }

        return currnode;

    }

    Double showbalance(Node node) {
        Double BL;
        if (node == null) {
            BL = 0.0;
        } else {
            BL = GetNodeHeight(node.left) - GetNodeHeight(node.right);
        }
        return BL;

    }

    private boolean Search(Node node, double value) {

        if (node == null) {
            return false;
        }

        if (node.value == value)
            return true;

        if (value < node.value)
            return Search(node.left, value);
        else
            return Search(node.right, value);
    }


    private Node addfunction(Node node, double value) {

        if (node == null) {
            node = new Node(value);
            return node;
        }

        if (value > node.value) {
            node.right = addfunction(node.right, value);
        } else if (value < node.value) {
            node.left = addfunction(node.left, value);
        } else {
            return node;
        }


        if (GetNodeHeight(node.left) > GetNodeHeight(node.right)) {
            node.height = GetNodeHeight(node.left) + 1;
        } else {
            node.height = GetNodeHeight(node.right) + 1;
        }

        double BL;

        if (node == null) {
            BL = 0;
        } else {
            BL = GetNodeHeight(node.left) - GetNodeHeight(node.right);
        }


        if (BL > 1 && value < node.left.value)
            return RotateToRight_Double(node);

        if (BL < -1 && value > node.right.value && BL < -1)
            return RotateToLeft_Double(node);

        if (BL > 1 && value > node.left.value) {
            node.left = RotateToLeft_Double(node.left);
            return RotateToRight_Double(node);
        }

        if (BL < -1 && value < node.right.value && BL < -1) {
            node.right = RotateToRight_Double(node.right);
            return RotateToLeft_Double(node);
        }

        return node;
    }

    private Node RotateToRight_Double(Node currnode1) {

        Node currnode2 = currnode1.left;
        Node currnode3 = currnode2.right;
        currnode2.right = currnode1;
        currnode1.left = currnode3;

        if (GetNodeHeight(currnode1.left) > GetNodeHeight(currnode1.right)) {
            currnode1.height = GetNodeHeight(currnode1.left);
        } else {
            currnode1.height = GetNodeHeight(currnode1.right);
        }
        currnode1.height++;

        if (GetNodeHeight(currnode2.left) > GetNodeHeight(currnode2.right)) {
            currnode2.height = GetNodeHeight(currnode2.left);
        } else {
            currnode2.height = GetNodeHeight(currnode2.right);
        }
        currnode2.height++;

        System.out.println("balancing " + currnode1.value);
        return currnode2;
    }

    private Node RotateToLeft_Double(Node currnode1) {

        Node currnode2 = currnode1.right;
        Node currnode3 = currnode2.left;
        currnode2.left = currnode1;
        currnode1.right = currnode3;

        if (GetNodeHeight(currnode1.left) > GetNodeHeight(currnode1.right)) {
            currnode1.height = GetNodeHeight(currnode1.left);
        } else {
            currnode1.height = GetNodeHeight(currnode1.right);
        }
        currnode1.height++;

        if (GetNodeHeight(currnode2.left) > GetNodeHeight(currnode2.right)) {
            currnode2.height = GetNodeHeight(currnode2.left);
        } else {
            currnode2.height = GetNodeHeight(currnode2.right);
        }
        currnode2.height++;

        System.out.println("balancing " + currnode1.value);
        return currnode2;
    }

    public void doremove(Node node, Double item) {
        if (node == null) {
            System.out.println("does not exist");
            return;
        } else {
            if (node.value > item) {
                doremove(node.left, item);
            } else if (node.value < item) {
                doremove(node.right, item);
            } else if (node.value == item) {
                removeFoundNode(node);
            }
        }
    }

    public void removeFoundNode(Node node) {
        Node currnode;
        if (node.left == null || node.right == null) {
            if (node.root == null) {
                System.out.println("removed");
                this.root = null;
                node = null;
                return;
            }
            currnode = node;
        } else {
            currnode = successor(node);
            System.out.println("removed");
            node.value = currnode.value;
        }

        Node currnode2;
        if (currnode.left != null) {
            System.out.println("removed");
            currnode2 = currnode.left;
        } else {
            System.out.println("removed");
            currnode2 = currnode.right;
        }

        if (currnode2 != null) {
            currnode2.root = currnode.root;
        }

        if (currnode.root == null) {
            this.root = currnode2;
        } else {
            if (currnode == currnode.root.left) {
                System.out.println("removed");
                currnode.root.left = currnode2;
            } else {
                System.out.println("removed");
                currnode.root.right = currnode2;
            }

            double BL;

            if (node == null) {
                BL = 0;
            } else {
                BL = GetNodeHeight(node.left) - GetNodeHeight(node.right);
            }

            if (BL > 1 && value < node.left.value)
                RotateToRight_Double(node);

            if (BL < -1 && value > node.right.value && BL < -1)
                RotateToLeft_Double(node);

            if (BL > 1 && value > node.left.value) {
                node.left = RotateToLeft_Double(node.left);
                RotateToRight_Double(node);
            }

            if (BL < -1 && value < node.right.value && BL < -1) {
                node.right = RotateToRight_Double(node.right);
                RotateToLeft_Double(node);
            }
        }
        currnode = null;
    }

    public Node successor(Node node) {
        if (node.right != null) {
            Node currnode = node.right;
            while (currnode.left != null) {
                currnode = currnode.left;
            }
            return currnode;
        } else {
            Node currnode2 = node.root;
            while (currnode2 != null && node == currnode2.right) {
                node = currnode2;
                currnode2 = node.root;
            }
            return currnode2;
        }
    }

}

